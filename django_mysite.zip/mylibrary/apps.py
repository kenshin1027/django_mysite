from django.apps import AppConfig


class MylibraryConfig(AppConfig):
    name = 'mylibrary'
