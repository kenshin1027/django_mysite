from django.apps import AppConfig


class TestdjConfig(AppConfig):
    name = 'testdj'
